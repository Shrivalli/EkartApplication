﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;


namespace ExamApplication.Controllers
{
    public class ProductController : Controller
    {
        OnlineShoppingEntities db = new OnlineShoppingEntities();
        Product1 p = new Product1();
        //
        // GET: /Product/

        public ActionResult Index()
        {
            IEnumerable<Product1> products = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53161/");
                //HTTP GET
                var responseTask = client.GetAsync("Product");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    //   var readTask = result.Content.ReadAsAsync<IEnumerable<ProductVM>>();
                    products = db.Product1.ToList();
                    //   readTask.Wait();

                    //  students = readTask.Result;
                }
                else
                {
                    products = Enumerable.Empty<Product1>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(products);
        }


        public ActionResult Edit(int id)
        {
            ProductVM p1 = null;
           

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:53161/");
                //HTTP GET
                var responseTask = client.GetAsync("product?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                  //  var readTask = result.Content.ReadAsAsync<ProductVM>();
                    //readTask.Wait();

//                    p1 = readTask.Result;
                    p = db.Product1.Find(id);
                }
            }

            return View(p);
        }


      
       

    }
}