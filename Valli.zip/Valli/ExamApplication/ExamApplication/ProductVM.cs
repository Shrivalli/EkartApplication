﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExamApplication
{
    public class ProductVM
    {
        public int ProductID { get; set; }
        public string Title { get; set; }
        public Nullable<double> Price { get; set; }
        public string InStock { get; set; }
        public string Category { get; set; }
        public Nullable<System.DateTime> DateOfExpiry { get; set; }
        public Nullable<bool> FreeDelivery { get; set; }
    }
}